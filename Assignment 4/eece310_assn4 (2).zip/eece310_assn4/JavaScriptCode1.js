function test(a,b) {
    id1 = 1138 - 327;
    foo(id1);
    id2 = id1 * id1;
    id3 = id2 - (3 + id1);
    if (id3 == id1 + id2) {
        foo3(id9);
    }
}

function test2(a,b,c) {
    t1 = 3;
    t2 = 9;
    if (t1 == 3) {
        if ((t1 > t2) && t2 != 8) {
            alert(t2);
        }
    }
}

function test3(a,b) {
    y = 7*a;
    x = 9*y;
    if (x >= 0 && y >= 0) {
        z = y + x;
        if (z == 20) {
            alert(z);
        }
    }
}