function bar(p,q) {
    m_a = true;
    if (p != q && p > q) {
        m_a = false;
    }
    
    return m_a;
}