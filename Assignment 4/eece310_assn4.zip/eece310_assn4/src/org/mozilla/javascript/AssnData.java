package org.mozilla.javascript;

public class AssnData {
	public String assnName;
	public String assnLeft;
	public String assnRight;
	public String functionName;
}