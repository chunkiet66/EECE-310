package org.mozilla.javascript;

public class IfData {
	public String ifName;
	public String ifCondition;
	public String functionName;
}