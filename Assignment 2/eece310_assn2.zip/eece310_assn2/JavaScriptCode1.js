function foo(a,b,c) {
    id1 = 0;
    if (a == b + c) {
        id1 += a;
    }
    id2 = id1 + 0xAB + 071;  
}