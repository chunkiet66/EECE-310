id1 = 1138 - 327;
foo(id1);
id2 = id1 * id1;
id3 = id2 - (3 + id1);